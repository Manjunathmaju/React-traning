import React, { Fragment, useState } from "react";
import "./SingleTodo.css";
import Checkbox from "./Checkbox";
import DeleteTodo from "./DeleteTodo";
function SingleTodo(props) {
  // const date = JSON.stringify(new Date());
  // const [curDate,setCurDate]=useState()
  // setCurDate(new Date().toLocaleString())
  const curDate = new Date().toLocaleString();

  return (
    <div className="singleTodo">
      <h3>{props.task}</h3>
      <span>
        <DeleteTodo id={props.id} deleteFun={props.deleteFun} />
        <Checkbox />
      </span>
      <p>created At: {props.curDate}</p>
    </div>
  );
}

export default SingleTodo;
