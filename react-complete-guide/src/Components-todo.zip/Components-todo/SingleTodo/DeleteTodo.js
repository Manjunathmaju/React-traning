import React, { Fragment } from 'react'
import './SingleTodo.css'

// function Hoc(props){
//   const {componetn,array}=props;
//   const res=array.map((elem)=>{
// <Card>{elem}</Card>
//   })
  
// }


function DeleteTodo(props) {

  return (
    <Fragment>
       <button
          id={props.id}
          className="delBtn"
          onClick={(e) => props.deleteFun(e.target.id)}
        >
          delete
        </button>
    </Fragment>
  )
}

export default DeleteTodo