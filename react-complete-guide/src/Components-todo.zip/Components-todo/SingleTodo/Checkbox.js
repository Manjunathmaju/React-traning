import React, { Fragment, useState }from 'react'
import './SingleTodo.css'
function Checkbox() {
    const [isChecked, setIsChecked] = useState(false);
    const [isCompleted, setIsCompleted] = useState('Incompleted');

    const handleChange = event => {
      if (event.target.checked) {
        console.log('✅ Checkbox is checked');
        setIsCompleted('Completed')
      } else {
        console.log('⛔️ Checkbox is NOT checked');
        setIsCompleted('Incompleted')
      }
      setIsChecked(current => !current);

    };
  
    return (
      <Fragment>
        <label htmlFor="subscribe" className='checkboxLable'>
          <input
            type="checkbox"
            value={isChecked}
            onChange={handleChange}
            id="subscribe"
            name="subscribe"
            
          />
          {isCompleted}
        </label>
      </Fragment>
    );
}

export default Checkbox

