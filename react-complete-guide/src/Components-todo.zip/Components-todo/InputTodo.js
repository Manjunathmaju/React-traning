// import { render } from "@testing-library/react";
import React, { useState } from "react";

function InputTodo(props) {
  const [message, setMessage] = useState("");

  const handleChange = (event) => {
    setMessage(event.target.value);
  };

  const handleAddBtn = () => {
    message ? props.saveTodo(message) : console.log("enter the task");
    setMessage("");
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      message ? props.saveTodo(message) : console.log("enter the task");
      setMessage("");
    }
    console.log("User pressed: ", event.key);
  };

  return (
    <div onKeyDown={handleKeyDown}>
      <h1>Todo</h1>
      <input
        type="text"
        value={message}
        onChange={(e) => {
          handleChange(e);
        }}
      />

      <button onClick={handleAddBtn}>Add</button>
    </div>
  );
}

export default InputTodo;
