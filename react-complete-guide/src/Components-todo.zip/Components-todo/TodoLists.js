import React from 'react'
import SingleTodo from './SingleTodo/SingleTodo'
function TodoLists(props) {
    console.log()
    const todos = props.todos
    
    const list = todos.map((per, index) => <SingleTodo 
    key={index} 
    deleteFun={props.deleteFun} 
    task={per} 
    id={index} />)

    return (
        <div>
            {list}
        </div>
    )
}

export default TodoLists
