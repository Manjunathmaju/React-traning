import React, { useState } from "react";
import InputTodo from "./InputTodo";
import TodoLists from "./TodoLists";
// import UserProvider from "./UserContext";

let ar = [];
// let taskObject={};
// taskObject[null]={
//     id:null,
//     task:undefined,
//     status:false
// }
function Todo() {
  // const [item,setItem]=useState(ar)
  const [todo, setTodo] = useState(ar);
    // const [task, setTask] = useState(taskObject);

  const deleteFun = (id) => {
    ar.splice(id, 1);
    setTodo([...ar]);
    console.log(todo);
  };
  
  const handleSave = (val) => {
    setTodo(ar.push(val));
//     setTask({[Date.now()]:{id:Date.now(),task:val,status:false}})
// console.log(task)
  };

  return (
    <div>
      <InputTodo saveTodo={handleSave} />
      <TodoLists todos={ar} deleteFun={deleteFun} />

      {/* <UserProvider deleteFun={deleteFun}>
        <SingleTodo />
      </UserProvider> */}
    </div>
  );
}

export default Todo;
