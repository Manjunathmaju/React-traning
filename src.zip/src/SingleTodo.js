import React from "react";

function SingleTodo(props) {
  return (
    <div>
        <p>
        <button type="submit">Delete</button>
         {props.task}
        <input type='checkbox'/>
        </p>
    
    </div>
  );
}

export default SingleTodo;
