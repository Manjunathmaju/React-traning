import React, { Component } from "react";
import SingleTodo from "./SingleTodo";

export class InputField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      val: "",
    };
  }

  todoList = [];
  tasks;
  handleUserVal = (event) => {
    this.setState({
      val: event.target.value,
    });
  };
  handleTodoList = () => {
    this.setState({ val: "" });
    this.todoList.push(this.state.val);
    this.tasks=this.todoList.map((todoInArray,index)=><SingleTodo key={index} task={todoInArray}/>) 
    console.log(this.tasks);
  };
  render() {
    return (
      <div>
        <h1>Todo List</h1>
        <input
          type="text"
          value={this.state.val}
          onChange={this.handleUserVal}
        />
        <button onClick={this.handleTodoList}>Add</button>
        {this.tasks}
      </div>
    );
  }
}

export default InputField;
